import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Policies } from '../_classes/policies';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Users } from '../_classes/users';
import { LoginDetails } from '../_classes/login-details';
@Injectable({
  providedIn: 'root'
})
export class PolicyService {

  constructor(private http: HttpClient) {
  }
  Login(credentials: LoginDetails): Observable<object> {
    return this.http.post<object>("http://localhost:8089/auth/signin", credentials);
  }

  Register(user: Users): Observable<object> {
    return this.http.post<Object>("http://localhost:8089/auth/signup", user);
  }

  policyregister(policy: Policies): Observable<Object> {
    return this.http.post<Object>("http://localhost:8089/policies/register", policy);

  }

  getPolicies(): Observable<Object> {
    return this.http.get("http://localhost:8089/policies/getpolicieslist");
  }

  getdocuments(policyId: string) {

    let headerOptions = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/pdf'

    });

    let request = { headers: headerOptions, responseType: 'blob' as 'blob' };
    this.http.get(`http://localhost:8089/policies/pdf/${policyId}`,request).pipe(map((data: any) => {
      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(new Blob([data]));
      link.download = 'policydocument.pdf';
      link.click();
      window.URL.revokeObjectURL(link.href);

    })).subscribe((result: any) => {
    });

  }

  searchPolicy(): Observable<any> {    //policyType:string): Observable<any> {  
    return this.http.get<Policies>("http://localhost:8089/policies/getpolicy/{policyType}");
  }

}
