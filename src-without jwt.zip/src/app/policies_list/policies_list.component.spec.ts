import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { PolicyService } from '../_services/policy.service';
import { FormsModule } from '@angular/forms';
import { PolicyListComponent } from './policies_list.component';

describe('PolicyListComponent', () => {
  let component: PolicyListComponent;
  let fixture: ComponentFixture<PolicyListComponent>;

  beforeEach(() => {
    const policyServiceStub = () => ({
      getPolicies: () => ({}),
      getdocuments: (policyId: any) => ({}),
      searchPolicy: () => ({})
    });
    TestBed.configureTestingModule({
      imports: [FormsModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [PolicyListComponent],
      providers: [{ provide: PolicyService, useFactory: policyServiceStub }]
    });
    fixture = TestBed.createComponent(PolicyListComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`policy1 has default value`, () => {
    expect(component.policy1).toEqual([]);
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      const policyServiceStub: PolicyService = fixture.debugElement.injector.get(
        PolicyService
      );
      spyOn(policyServiceStub, 'getPolicies').and.callThrough();
      component.ngOnInit();
      expect(policyServiceStub.getPolicies).toHaveBeenCalled();
    });
  });

  describe('getPolicies', () => {
    it('makes expected calls', () => {
      const policyServiceStub: PolicyService = fixture.debugElement.injector.get(
        PolicyService
      );
      spyOn(policyServiceStub, 'getPolicies').and.callThrough();
      component.getPolicies();
      expect(policyServiceStub.getPolicies).toHaveBeenCalled();
    });
  });

  describe('searchPolicies', () => {
    it('makes expected calls', () => {
      const policyServiceStub: PolicyService = fixture.debugElement.injector.get(
        PolicyService
      );
      spyOn(policyServiceStub, 'searchPolicy').and.callThrough();
      component.searchPolicies();
      expect(policyServiceStub.searchPolicy).toHaveBeenCalled();
    });
  });
});
