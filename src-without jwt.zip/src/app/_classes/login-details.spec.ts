import { LoginDetails } from '../_classes/login-details';

describe('LoginDetails', () => {
  it('should create an instance', () => {
    expect(new LoginDetails()).toBeTruthy();
  });
});
