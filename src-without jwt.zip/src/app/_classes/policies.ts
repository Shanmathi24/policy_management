export class Policies {

  policyName!:string;
  startDate!:Date;
  duration!:number;
  company!:string;
  initialDeposit!:number;
  policyType!:string;
  userType!:string;
  termsPerYear!:number;
  termAmount!:number;
  interest!:number;
  

}
