import { Component, OnInit } from '@angular/core';
import { PolicyService } from '../_services/policy.service';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  regForm: FormGroup
  msg: boolean = false;
  emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";
  constructor(private fb: FormBuilder, private policyservice: PolicyService,private router:Router) {
    this.regForm = this.fb.group({

      firstName: this.fb.control('', [Validators.required, Validators.minLength(3), Validators.maxLength(15)]),
      address:this.fb.control('', [Validators.required, Validators.minLength(7), Validators.maxLength(15)]),
      employerName:this.fb.control('', [Validators.required, Validators.minLength(3), Validators.maxLength(15)]),
      lastName: this.fb.control('', [Validators.minLength(2), Validators.maxLength(15)]),
      emailAddress: this.fb.control('', [Validators.required, Validators.pattern(this.emailPattern)]),
      contactNo: this.fb.control('', [Validators.required, Validators.pattern("[6-9][0-9]{9}")]),
      role: this.fb.control('', Validators.required),
      employerType: this.fb.control('', Validators.required),
      gender: this.fb.control('', Validators.required),
      salary: this.fb.control('', Validators.required),
      company: this.fb.control('', Validators.required),
      qualification: this.fb.control('', Validators.required),
      dateOfBirth: this.fb.control('', Validators.required),
      panNo:this.fb.control('',[Validators.required, Validators.pattern("[A-Z]{5}[0-9]{4}[A-Z]{1}")]),

    })
  }

  ngOnInit(): void {
  }

  onSubmit() {
    
    if (this.regForm.valid) {
      this.policyservice.Register(this.regForm.value).subscribe(data => {
          Swal.fire('Success!', 'Registration successfull', 'success')
          this.login();
    
      });
    
    }}
  check(input: string) {
    return (this.regForm.get(input)?.errors?.['required'] && this.regForm.get(input)?.touched) || (this.regForm.get(input)?.errors?.['required'] && this.msg)
  }

  checkLength(input: string) {
    return (this.regForm.get(input)?.errors?.['minlength'] || this.regForm.get(input)?.errors?.['maxlength']);
  }

   login(){
     this.router.navigate(['/login']);
   }

  
}
