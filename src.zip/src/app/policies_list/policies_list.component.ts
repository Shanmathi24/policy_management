import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Policies } from '../_classes/policies';
import { PolicyService } from '../_services/policy.service';
import * as jsPDF from 'jspdf';
import { HttpHeaders } from '@angular/common/http';
import { EventEmitter } from 'stream';
import { FormControl, FormGroup } from '@angular/forms';
import { LoginDetails } from '../_classes/login-details';
import { TokenService } from '../_services/token.service';

@Component({
  selector: 'app-policies_list',
  templateUrl: './policies_list.component.html',
  styleUrls: ['./policies_list.component.css']
})
export class PolicyListComponent implements OnInit {
  policyType!: string;
  //currentPolicy: string[]=[];
  policies: any;
  search: any;
  policy!: Policies;
  policy1: Policies[] = [];
  PDF_URL: any;
  http: any;
  data: any;
  PolicyType: any;
  Duration: any;
  Company: any;
  policyId: any;
  PolicyName: any;
  constructor(private policyService: PolicyService, private login: LoginDetails, public tokenservice: TokenService) { }

  ngOnInit(): void {
    this.policies = this.policyService.getPolicies();
    //console.log(this.tokenservice.getToken());

  }


  getPolicies() {
     //this.tokenservice.getToken();
    this.policyService.getPolicies();



  }
  searchPolicies() {
    //this.tokenservice.getToken();
    this.policyService.searchPolicy();
    
  }
  downloadpdf(policyId: string) {
    //this.tokenservice.getToken();
    this.policyService.getdocuments(policyId);

  }


}

