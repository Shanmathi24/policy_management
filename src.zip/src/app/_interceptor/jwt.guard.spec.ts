import { TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { PolicyService } from '../_services/policy.service';
import { TokenService } from '../_services/token.service';
import { JwtGuard } from './jwt.guard';

describe('JwtGuard', () => {
  let service: JwtGuard;

  beforeEach(() => {
    const routerStub = () => ({ navigate: (array: any) => ({}) });
    const policyServiceStub = () => ({ roleMatch: (role: any) => ({}) });
    const tokenServiceStub = () => ({ getToken: () => ({}) });
    TestBed.configureTestingModule({
      providers: [
        JwtGuard,
        { provide: Router, useFactory: routerStub },
        { provide: PolicyService, useFactory: policyServiceStub },
        { provide: TokenService, useFactory: tokenServiceStub }
      ]
    });
    service = TestBed.inject(JwtGuard);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('canActivate', () => {
    it('makes expected calls', () => {
      const activatedRouteSnapshotStub: ActivatedRouteSnapshot = <any>{};
      const routerStub: Router = TestBed.inject(Router);
      const policyServiceStub: PolicyService = TestBed.inject(PolicyService);
      const tokenServiceStub: TokenService = TestBed.inject(TokenService);
      spyOn(routerStub, 'navigate').and.callThrough();
      spyOn(policyServiceStub, 'roleMatch').and.callThrough();
      spyOn(tokenServiceStub, 'getToken').and.callThrough();
      service.canActivate(activatedRouteSnapshotStub);
      expect(routerStub.navigate).toHaveBeenCalled();
      expect(policyServiceStub.roleMatch).toHaveBeenCalled();
      expect(tokenServiceStub.getToken).toHaveBeenCalled();
    });
  });
});
