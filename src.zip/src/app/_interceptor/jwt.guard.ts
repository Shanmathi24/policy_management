import { Injectable } from '@angular/core';
import {CanActivate,ActivatedRouteSnapshot,UrlTree,Router} from '@angular/router';
import { Observable } from 'rxjs';
import { PolicyService } from '../_services/policy.service';
import { TokenService } from '../_services/token.service';

@Injectable({
  providedIn: 'root',
})
export class JwtGuard implements CanActivate {
  constructor(private tokenservice: TokenService,private router: Router,private policyService: PolicyService) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (this.tokenservice.getToken() !== null) {
      const role = route.data['roles'] as Array<string>;
      if (role) {
        const matches = this.policyService.roleMatch(role);
        if (matches) {
          return true;
        } else {
          return false;
        }
      }
    }
    this.router.navigate(['/login']);
    return false;
  }
}