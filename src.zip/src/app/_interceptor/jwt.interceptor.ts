import {HttpErrorResponse,HttpEvent,HttpHandler,HttpInterceptor,HttpRequest} from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { TokenService } from '../_services/token.service';
import { Injectable } from '@angular/core';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
constructor(private tokenService: TokenService,
  private router:Router) {}

intercept(request: HttpRequest<any>,next: HttpHandler
): Observable<HttpEvent<any>> {
  if (request.headers.get('No-Auth') === 'True') {
    return next.handle(request.clone());
  }

  const token = this.tokenService.getToken();

  request = this.addToken(request,token);

  return next.handle(request).pipe(
      catchError(
          (err:HttpErrorResponse) => {
              
              if(err.status === 401) {
                  this.router.navigate(['/login']);
              } 
              
              return throwError("Something went wrong");
          }
      )
  );
}


public addToken(requests:HttpRequest<any>, token:any) {
    return requests.clone(
        {
            setHeaders: {
                Authorization : `Bearer ${token}`
            }
        }
    );
}












// import {HttpEvent } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';

// import { Observable } from 'rxjs';
// import { TokenService } from '../_services/token.service';

// //const TOKEN = 'Authorization';       

// @Injectable()
// export class JwtInterceptor implements HttpInterceptor {
//   constructor(private tokenservice: TokenService) { }

//   intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
   
//     let token = this.tokenservice.getToken();
//    // if (token != null) 

//       const Authrequest = request.clone({   
//                      setHeaders: {
//                        Authorization : `Bearer ${token}`}})
                   
                              
  
//         return next.handle(Authrequest);
                     
//                      }
// // export const authInterceptorProviders = [
// //   { 
// //     provide: HTTP_INTERCEPTORS,
// //     useClass: JwtInterceptor,
// //     multi: true
 }