import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { CreatePolicyComponent } from './create-policy/create-policy.component';
import { PolicyListComponent } from './policies_list/policies_list.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { JwtGuard } from './_interceptor/jwt.guard';
import { JwtInterceptor } from './_interceptor/jwt.interceptor';
import { PolicyService } from './_services/policy.service';
import { LoginDetails } from './_classes/login-details';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    CreatePolicyComponent,
    PolicyListComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    BrowserAnimationsModule
    //DataTablesModule
   // MatButtonModule,
    //MatCheckboxModule,
    //MatToolbarModule
  ],
  
  providers: [
    JwtGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass:JwtInterceptor,
      multi:true
    },PolicyService,LoginDetails],
    bootstrap: [AppComponent]
})
export class AppModule { }
