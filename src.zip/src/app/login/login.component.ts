import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PolicyService } from '../_services/policy.service';
import { LoginDetails } from '../_classes/login-details';
import { TokenService } from '../_services/token.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  result: any
  msg: boolean = false;
  loginForm: FormGroup
  isLogin!: Boolean;
  admin!: boolean;
  user!:boolean;
  isLoggedIn = false;
  isLoginFailed = false;
  login!:LoginDetails;
  token!:string;
  constructor(private fb: FormBuilder, private router: Router, private policyservice: PolicyService,public tokenservice:TokenService ) {
    this.loginForm = this.fb.group({
      userId: this.fb.control('', Validators.required),
      password: this.fb.control('', Validators.required)

    })
  }

  ngOnInit(): void {
    if (this.tokenservice.getToken()) {
      this.isLoggedIn = true;
  }
}
  onSubmit() {
    this.policyservice.Login(this.loginForm.value).subscribe(
      
      (response: any) => {
        this.tokenservice.setRoles(response.user.role);
        this.tokenservice.setToken(response.jwtToken);
        const role = response.user.role[0].roleType;
        if (role == 'Admin') {
         // this.admin=true;
          this.router.navigate(['/createpolicy']);
        } else if(role == 'User') {
           //this.user=true;
          this.router.navigate(['/policylist']);
        } 
       
      } 
  
  )}
  
      check(input: string) {
        return (this.loginForm.get(input)?.invalid && this.loginForm.get(input)?.touched) || (this.loginForm.get(input)?.invalid && this.msg)
      }
      registration() {
        this.router.navigate(['/register']);
      }}