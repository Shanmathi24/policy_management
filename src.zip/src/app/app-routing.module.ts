import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { CreatePolicyComponent } from './create-policy/create-policy.component';
import { PolicyListComponent } from './policies_list/policies_list.component';
import { JwtGuard } from './_interceptor/jwt.guard';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'policylist', component:PolicyListComponent , canActivate:[JwtGuard], data:{roles:['User']} },
  { path: 'createpolicy', component:  CreatePolicyComponent,  canActivate:[JwtGuard], data:{roles:['Admin']} },
  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
