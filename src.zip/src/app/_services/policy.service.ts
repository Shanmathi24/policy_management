import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Policies } from '../_classes/policies';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Users } from '../_classes/users';
import { LoginDetails } from '../_classes/login-details';
import { TokenService } from './token.service';
const header = {
  headers: new HttpHeaders({ 'No-Auth': 'True' })
}

@Injectable({
  providedIn: 'root'
})
export class PolicyService {

  user!: Observable<Users>[];

  constructor(private http: HttpClient, private tokenservice: TokenService) { }


  Login(credentials: LoginDetails): Observable<any> {
    return this.http.post("http://localhost:8001/auth/signin", credentials, header);
  }


  public roleMatch(allowedRoles: any[]): boolean {
    let isMatching = false;
    const roleInput: any = this.tokenservice.getRoles();
    if (roleInput != null && roleInput) {
      for (let i = 0; i < roleInput.length; i++) {
        for (let j = 0; j < allowedRoles.length; j++) {
          if (roleInput[i].roleType === allowedRoles[j]) {
            isMatching = true;
            return isMatching;
          } 
        }
      }
    }
    return isMatching;
  }

  Register(user: Users): Observable<any> {
    return this.http.post('http://localhost:8001/auth/signup', user, { responseType: 'text' });

  }

  policyregister(policy: Policies): Observable<any> {
    return this.http.post('http://localhost:8001/policies/register', policy,);

  }

  getPolicies(): Observable<any> {
    return this.http.get<any>('http://localhost:8001/policies/getpolicieslist');
  }

  searchPolicy(): Observable<any> {
    return this.http.get('http://localhost:8001/policies/getpolicy/{policyType}');
  }

  getdocuments(policyId: string) {
    let request = { headers: { 'Content-Type': 'application/json' }, responseType: 'blob' as 'blob' };
    this.http.get(`http://localhost:8001/policies/pdf${policyId}`, request).pipe(map((data: any) => {
      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(new Blob([data]));
      link.download = 'policydocument.pdf';
      link.click();
      window.URL.revokeObjectURL(link.href);

    })).subscribe((result: any) => {
    });

  }


}
