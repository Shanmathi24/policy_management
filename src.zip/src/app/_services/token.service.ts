import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  constructor() { }

  public setRoles(roles: any) {
    localStorage.setItem('roles', JSON.stringify(roles));
  }

  public getRoles(): any {
    return JSON.parse(localStorage.getItem('roles') || 'null' || '{}');
  }

  public setToken(jwtToken: string) {
    localStorage.setItem('jwtToken', jwtToken);
  }

  public getToken() {
    return localStorage.getItem('jwtToken');
  }

  public isLoggedIn() {
    return this.getRoles() && this.getToken();
  }
}
