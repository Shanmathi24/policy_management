import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { PolicyService } from '../_services/policy.service';
import { TokenService } from '../_services/token.service';
import { CreatePolicyComponent } from './create-policy.component';

describe('CreatePolicyComponent', () => {
  let component: CreatePolicyComponent;
  let fixture: ComponentFixture<CreatePolicyComponent>;

  beforeEach(() => {
    const formBuilderStub = () => ({
      group: (object: any) => ({}),
      control: (string: any, required: any) => ({})
    });
    const routerStub = () => ({ navigate: (array: any) => ({}) });
    const policyServiceStub = () => ({
      policyregister: (value: any) => ({ subscribe: (f: (arg0: {}) => any) => f({}) })
    });
    const tokenServiceStub = () => ({});
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [CreatePolicyComponent],
      providers: [
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: Router, useFactory: routerStub },
        { provide: PolicyService, useFactory: policyServiceStub },
        { provide: TokenService, useFactory: tokenServiceStub }
      ]
    });
    fixture = TestBed.createComponent(CreatePolicyComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`msg has default value`, () => {
    expect(component.msg).toEqual(false);
  });

  describe('onSubmit', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const policyServiceStub: PolicyService = fixture.debugElement.injector.get(
        PolicyService
      );
      spyOn(routerStub, 'navigate').and.callThrough();
      spyOn(policyServiceStub, 'policyregister').and.callThrough();
      component.onSubmit();
      expect(routerStub.navigate).toHaveBeenCalled();
      expect(policyServiceStub.policyregister).toHaveBeenCalled();
    });
  });
});
