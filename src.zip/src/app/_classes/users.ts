import { Injectable } from "@angular/core";

@Injectable()

export class Users {
    contactNo!:number;
    firstName!:string;
    lastName!:string;
    emailAddress!:string;
    address!:string;
    panNo!:string;
    company!:string;
    dateOfBirth!:Date;
    qualification!:string;
    gender!:string;
    salary!:number;
    employerType!:string;
    employerName!:string
    role!: string;
}
