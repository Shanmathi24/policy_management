import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyService } from '../_services/policy.service';
import { TokenService } from '../_services/token.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HomeComponent } from './home.component';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(() => {
    const routerStub = () => ({ navigate: (array: any) => ({}) });
    const policyServiceStub = () => ({});
    const tokenServiceStub = () => ({
      isLoggedIn: () => ({}),
      clear: () => ({})
    });
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [HomeComponent],
      providers: [
        { provide: Router, useFactory: routerStub },
        { provide: PolicyService, useFactory: policyServiceStub },
        { provide: TokenService, useFactory: tokenServiceStub }
      ]
    });
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  describe('login', () => {
    it('makes expected calls', () => {
      const tokenServiceStub: TokenService = fixture.debugElement.injector.get(
        TokenService
      );
      spyOn(tokenServiceStub, 'isLoggedIn').and.callThrough();
      component.login();
      expect(tokenServiceStub.isLoggedIn).toHaveBeenCalled();
    });
  });

  describe('register', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.register();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });

  
});
