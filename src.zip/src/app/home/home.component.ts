import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyService } from '../_services/policy.service';
import { TokenService } from '../_services/token.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public policyService:PolicyService,public router:Router,public tokenservice:TokenService) { }

  ngOnInit(): void {
      }
      login(){
        return this.tokenservice.isLoggedIn();
       // this.router.navigate(['/login']);
      }
      register()
      {
        this.router.navigate(['/register']);
      }
      
}
