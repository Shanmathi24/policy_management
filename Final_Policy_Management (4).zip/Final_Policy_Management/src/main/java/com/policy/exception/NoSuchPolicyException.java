package com.policy.exception;

import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class NoSuchPolicyException {
	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity<Object> handleException(NoSuchElementException e) {

		return new ResponseEntity<Object>("Policy Not Found", HttpStatus.NOT_FOUND);
	}
}