package com.policy.controller;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.policy.model.Admin;
import com.policy.model.AdminLogin;
import com.policy.model.User;
import com.policy.repo.UserRepo;
import com.policy.service.UserService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

	@Autowired
	private UserService userservice;

	@Autowired
	private UserRepo userrepo;
	
	@PostMapping("/register")
	public User registration(@RequestBody User user) {
		
		//user.setCompany(userservice.empType(user.getEmployerType(),user));	
		
	     user.setUserId(userservice.userType(user.getSalary(), user));
		
		/*
		 * String temp=userservice.userType(user.getSalary(),user)+ "-"
		 * +user.getRanNumber(); System.out.println(user.ranNumber);
		 * System.out.println(temp); user.userId=temp; user.setRanNumber(999 +
		 * user.getRanNumber());
		 */
       	user.setPassword(userservice.passwordGeneration());
		return user;

       	
		/*
		 * String usTy=((userservice.userType(user.getSalary(),user))); String
		 * usNum=userservice.findLast(); //(user.getRanNumber()); String
		 * usId=usTy+"-"+usNum; user.setUserId(usId); System.out.println(usId); return
		 * userservice.saveUser(user);
		 */
		
	}

	@GetMapping("/getpolicy/{policyType}")
	public List<Admin> searchPolicies(@PathVariable String policyType) throws NoSuchElementException {
		{

			return userservice.getPolicies(policyType);
		}

	}
	
	
	@PostMapping("/user/login")
	public ResponseEntity<?> loginUser(@RequestBody User userInput) {
      
		System.out.println(userInput);
	User user= userrepo.findByUserId(userInput.getUserId());
		
       if(user.getPassword().equals(userInput.getPassword()))
         return ResponseEntity.ok(user);
       
    	   return (ResponseEntity<?>) ResponseEntity.internalServerError();
	}
}