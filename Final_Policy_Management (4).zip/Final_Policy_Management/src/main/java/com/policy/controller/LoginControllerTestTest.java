package com.policy.controller;

import org.junit.Before;
import org.junit.Test;

public class LoginControllerTestTest {

    private LoginControllerTest loginControllerTestUnderTest;

    @Before
    public void setUp() {
        loginControllerTestUnderTest = new LoginControllerTest();
    }

    @Test
    public void testTestLoginAdmin() {
        // Setup
        // Run the test
        loginControllerTestUnderTest.testLoginAdmin();

        // Verify the results
    }
}
