package com.policy.controller;

import com.policy.model.AdminLogin;
import com.policy.repo.AdminLoginRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class LoginControllerTest {

    @Mock
    private AdminLoginRepo mockAdminloginrepo;

    @InjectMocks
    private LoginController loginControllerUnderTest;

    @Test
    public void testLoginAdmin() {
        // Setup
        final AdminLogin adminInput = new AdminLogin();

        // Configure AdminLoginRepo.findByUserId(...).
        final AdminLogin adminLogin = new AdminLogin();
        when(mockAdminloginrepo.findByUserId("userId")).thenReturn(adminLogin);

        // Run the test
        final ResponseEntity<?> result = loginControllerUnderTest.loginAdmin(adminInput);

        // Verify the results
    }
}
