package com.policy.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.policy.model.Admin;
import com.policy.model.User;

public interface UserService {

	public User saveUser(User user);

	
	public String passwordGeneration();

	public List<Admin> getPolicies(String policyType);

	public String userType(int salary,User user);

	public void sendEmail(User u,String subject) ;


	//public String findLast(String userType); //(int ranNumber);

	//public int fourdigitnum(); //(int ranNumber);
	//public Map<String, Object> userlogin(User userInput);


	//ResponseEntity<Object> save(User loginDetails);

	//public String empType(String employerType,User userr);
	
	
}
