package com.policy.service.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.policy.model.Admin;
import com.policy.model.User;
import com.policy.model.UserSequence;
import com.policy.repo.AdminRepo;
import com.policy.repo.UserRepo;
import com.policy.repo.UserSequenceRepo;
import com.policy.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userrepo;

	@Autowired
	private UserSequenceRepo userseqrepo;

	@Autowired
	private AdminRepo adminrepo;

	@Autowired
	public JavaMailSender mailSender;
	
	

	public User saveUser(User user) {
	    //findLast(); //(user.getRanNumber());
		User us = userrepo.save(user);
		userType(user.getSalary(),us);
		sendEmail(us, "Login Details");
		
		return us;
	}


	
	
	public String userType(int salary, User user) {
		int income = salary * 12;
		String userType = "";

		
		if (income <= 500000) {
			userType = "A";
		} else if (income >= 500000 && income <= 1000000) {
			userType = "B";
		} else if (income >= 1000000 && income <= 1500000) {
			userType = "C";
		} else if (income >= 1500000 && income <= 3000000) {
			userType = "D";
		} else {
			userType = "E";
		}


		System.out.println(user);
     		
       // String userId = userType + "-" + userrepo.findLast(userType);
        
		UserSequence useq=new UserSequence();
		useq.setUserType(userType);
		 //useq.setNumSeq(userrepo.findLast(userType));  
		     String numseq =  userrepo.findLast(userType);
		       useq.setNumSeq(numseq+1);
		       //String seq=userseqrepo.findNext(numseq, userType);
		String userId = userType + "-" +  numseq; //+seq ;
		System.out.println("Your user ID is " + userId);
		return userId;
	}

	public String passwordGeneration() {

		Calendar c = Calendar.getInstance();
		SimpleDateFormat s = new SimpleDateFormat("dd");
		Date date = new Date();
		String password = s.format(date);
		String pwd = password;
		int month = c.get(Calendar.MONTH);
		String monthName = "";

		switch (month) {

		case 0:
			monthName = "Jan";
			break;

		case 1:
			monthName = "Feb";
			break;

		case 2:
			monthName = "Mar";
			break;

		case 3:
			monthName = "Apr";
			break;

		case 4:
			monthName = "May";
			break;

		case 5:
			monthName = "Jun";
			break;

		case 6:
			monthName = "Jul";
			break;

		case 7:
			monthName = "Aug";
			break;

		case 8:
			monthName = "Sep";
			break;

		case 9:
			monthName = "Oct";
			break;

		case 10:
			monthName = "Nov";
			break;

		case 11:
			monthName = "Dec";
			break;

		}

		char[] characters = { '!', '@', '#', '$', '%', '^', '*', '(', ')', '_', '-' };

		String generatedpassword = pwd + monthName + characters[new Random().nextInt(characters.length)]
				+ new Random().nextInt(1000);

		log.info("Your password is: " + generatedpassword);
		return generatedpassword;
	}

	public void sendEmail(User u, String subject) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("shanproj24@gmail.com");
		message.setTo(u.getEmailAddress());

		message.setSubject(subject);

		String emailbody = "Hi " + u.getFirstName() + "," + "Your userId is " + u.getUserId() + " and Your Password is "
				+ u.getPassword();
		message.setText(emailbody);

		mailSender.send(message);

		System.out.println("Your userId is " + u.getUserId() + " and Your Password is " + u.getPassword());
	}

	public List<Admin> getPolicies(String policyType) {
		System.out.println(policyType);
		System.out.println(adminrepo.findAll());

		return adminrepo.findPolicy(policyType);
	}
	
	
	
	
	
	
	/*
	 * @Override public ResponseEntity<Object> save(User loginDetails) { // TODO
	 * Auto-generated method stub String usId1 = loginDetails.getUserId(); String
	 * role = loginDetails.getRole(); String passwd1=loginDetails.getPassword();
	 * 
	 * 
	 * if (role.equalsIgnoreCase("user") || role.equalsIgnoreCase("admin")) {
	 * 
	 * 
	 * userrepo.save(loginDetails); return new ResponseEntity<Object>(loginDetails,
	 * HttpStatus.OK); } else { return new
	 * ResponseEntity<Object>("Error: Role is Not Valid or NULL",
	 * HttpStatus.BAD_REQUEST); } }
	 * 
	 * 
	 * 
	 * @Override public Map<String, Object> userlogin(User userInput){ User
	 * loginDetails = userrepo.findByUserId(userInput.getUserId()); Map<String,
	 * Object> response = new HashMap<>(); if
	 * (loginDetails.getUserId().equals(userInput.getUserId()) &&
	 * loginDetails.getPassword().equals(userInput.getPassword())) { String role =
	 * loginDetails.getRole(); response.put("ResponseStatus", Boolean.TRUE); if
	 * (role.equalsIgnoreCase("Admin")) { response.put("ResponseType", "admin"); }
	 * else if (role.equalsIgnoreCase("User")) { response.put("ResponseType",
	 * "user"); } } else { response.put("ResponseStatus", Boolean.FALSE); } return
	 * response; }
	 * 
	 */	
}