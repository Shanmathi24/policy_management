package com.policy.service;

import java.time.LocalDate;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.policy.model.Admin;
import com.policy.model.AdminLogin;

@Service
public interface AdminService {

	public LocalDate calculateEndDate(LocalDate startDate, int duration,Admin admin);
	
	public String setPolicyId(String value);

	public Admin addPolicy(Admin admin);

	public int calculateMaturityAmount(int maturityAmount,Admin admin);

//	public AdminLogin adminlogin(String userId);

	//public Map<String, Object> adminlogin(Admin adminInput);

	//ResponseEntity<Object> save(Admin loginDetails);

}
