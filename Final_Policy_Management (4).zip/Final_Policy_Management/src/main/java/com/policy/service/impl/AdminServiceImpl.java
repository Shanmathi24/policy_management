package com.policy.service.impl;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
//import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.policy.model.Admin;
import com.policy.model.AdminLogin;
import com.policy.repo.AdminLoginRepo;
import com.policy.repo.AdminRepo;
import com.policy.service.AdminService;


@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private AdminRepo adminrepo;
	
	@Autowired
	private AdminLoginRepo adminloginrepo;
	
	public Admin addPolicy(Admin admin) {
		Admin adm = adminrepo.save(admin);
		displayMessage(adm, "Registration Successful");
		//setPolicyId("Insurance",adm);
		return adm ;
		//return adminrepo.save(admin); 
	}
	
	
	private String displayMessage(Admin adm, String string) {
		String msg="Dear Admin, " + " The policy is successfully registered." + " The policy " + adm.getPolicyId() 
		+ " is available to users from " + adm.getStartDate() + " to " + adm.getEndDate() + ".";
		System.out.println(msg);
		return msg;
		
	}


	public String setPolicyId(String value) {
	
		HashMap<String,String> policyName= new HashMap<>();
		policyName.put("Vehicle Insurance","VI");
		policyName.put("Life Insurance","LI");
		policyName.put("Travel Insurance","TI");
		policyName.put("Health Insurance","HI");
		policyName.put("Child Plans","CP");
		policyName.put("Retirement Plans","RP");
		
		
		SimpleDateFormat s = new SimpleDateFormat("yyyy");

		Date date = new Date();
		String policydate = s.format(date);
		String startdate =policydate ;

		String  policyId= policyName.get(value)+ "-" + startdate + "-" + new Random().nextInt(1000);
		return policyId;		
	}
	
	
	public LocalDate calculateEndDate(LocalDate startDate,int duration,Admin admin) 
	{ 
		LocalDate endDate= startDate.plusYears(duration); 
		System.out.println(endDate);
		return endDate;
	}

	
	public int calculateMaturityAmount(int maturityAmount,Admin admin) {
		System.out.println(maturityAmount);
		return maturityAmount;
	}

	/*
	 * public AdminLogin adminlogin(String userId) { return
	 * adminloginrepo.findByUserId(userId); }
	 */
	

	/*
	 * @Override public ResponseEntity<Object> save(Admin loginDetails) { // TODO
	 * Auto-generated method stub String usId = loginDetails.getUserId(); String
	 * role = loginDetails.getRole(); String passwd=loginDetails.getPassword();
	 * 
	 * 
	 * if (role.equalsIgnoreCase("user") || role.equalsIgnoreCase("admin")) {
	 * 
	 * 
	 * adminrepo.save(loginDetails); return new ResponseEntity<Object>(loginDetails,
	 * HttpStatus.OK); } else { return new
	 * ResponseEntity<Object>("Error: Role is Not Valid or NULL",
	 * HttpStatus.BAD_REQUEST); } }
	 * 
	 * 
	 * @Override public Map<String, Object> adminlogin(Admin adminInput){
	 * 
	 * Admin loginDetails =
	 * adminrepo.findByUserId(adminInput.setUserId("adminlic-1969")); Map<String,
	 * Object> response = new HashMap<>(); if
	 * (loginDetails.getUserId().equals(adminInput.getUserId()) &&
	 * loginDetails.getPassword().equals(adminInput.getPassword())) { String role =
	 * loginDetails.getRole(); response.put("ResponseStatus", Boolean.TRUE); if
	 * (role.equalsIgnoreCase("Admin")) { response.put("ResponseType", "admin"); }
	 * else if (role.equalsIgnoreCase("User")) { response.put("ResponseType",
	 * "user"); } } else { response.put("ResponseStatus", Boolean.FALSE); } return
	 * response; }
	 */
}