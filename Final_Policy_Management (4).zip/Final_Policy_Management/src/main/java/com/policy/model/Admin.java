package com.policy.model;

import java.time.LocalDate;
//import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "policy_registration")
public class Admin {

	@Id
	
	public String policyId;
	public String policyName;
	public LocalDate startDate;
	public int duration;
	public String company;
	public int initialDeposit;
	//public String emailAddress;
	public String policyType;
	public String userType;
	public int termsPerYear;
	public int termAmount;
	public int interest;
    public LocalDate endDate;
	public int maturityAmount;
	
	  //public String role;
	 
	 
}
