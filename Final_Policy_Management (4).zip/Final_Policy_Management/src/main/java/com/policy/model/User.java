package com.policy.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "user_registration")
public class User {

	@Id

	/*
	 * @SequenceGenerator(initialValue = 1000, name = "ranNumber")
	 * 
	 * @GeneratedValue(strategy = GenerationType.AUTO, generator = "seq")
	 * 
	 * @GenericGenerator(name = "seq", strategy = "increment")
	 * 
	 * 
	 * public int ranNumber;
	 */

	public long contactNo;
	public String firstName;
	public String lastName;
	public String emailAddress;
	public String address;
	public String panNo;
	public LocalDate dateOfBirth;
	public String qualification;
	// public String company;
	public String gender;
	public int salary;
	public String employerType;
	public String employerName;

	public String userId;
	public String password;

	// public String role;

}
