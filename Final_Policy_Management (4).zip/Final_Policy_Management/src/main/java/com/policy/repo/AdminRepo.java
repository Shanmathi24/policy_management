package com.policy.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.policy.model.Admin;
import com.policy.model.AdminLogin;

@Repository
public interface AdminRepo extends JpaRepository<Admin, String> {

	@Query(value = "SELECT * FROM policy_registration a WHERE a.duration=?1 OR a.company=?1 OR a.policy_type=?1 OR a.policy_id=?1 OR a.policy_name=?1", nativeQuery = true)

	List<Admin> findPolicy(String policyType);

	//AdminLogin findByUserId(String userId);

	
	//Admin findByUserId(Object setUserId);

}
