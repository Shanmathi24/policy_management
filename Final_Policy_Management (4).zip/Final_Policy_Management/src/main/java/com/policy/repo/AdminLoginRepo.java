package com.policy.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.policy.model.AdminLogin;
@Repository
public interface AdminLoginRepo extends JpaRepository<AdminLogin,String>{
	AdminLogin findByUserId(String userId);

}
