package com.policy.repo;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.policy.model.User;

@Repository
public interface UserRepo extends JpaRepository<User, Long> {


	@Query(value = "SELECT num_seq from user_sequence where user_type=?1 ", nativeQuery = true)
	String findLast(String userType);

	User findByUserId(String userId);
	
	
	
}
