package com.policy.repo;


import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.policy.model.UserSequence;

@Repository
@Transactional
public interface UserSequenceRepo extends JpaRepository<UserSequence, String> {

	
	  @Modifying
	  
	 /* @Query(value="Delete from user_sequence where user_type=:userType"
	  ,nativeQuery=true) public void delete(String userType);
	 */

	
	  @Query(value="update user_sequence SET num_seq=?1 WHERE user_type=?1"
	  ,nativeQuery = true) public String findNext(String numseq,String userType);
	 }