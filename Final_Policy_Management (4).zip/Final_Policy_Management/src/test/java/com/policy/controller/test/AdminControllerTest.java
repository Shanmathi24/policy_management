package com.policy.controller.test;

import com.policy.controller.AdminController;
import com.policy.model.Admin;
import com.policy.service.AdminService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AdminControllerTest {

	@Mock
	private AdminService mockAdminservice;

	@InjectMocks
	private AdminController adminControllerUnderTest;

	@Test
	public void testRegisterPolicy() {

		final Admin admin = new Admin();

		when(mockAdminservice.setPolicyId("value")).thenReturn("result");
		when(mockAdminservice.calculateEndDate(eq(LocalDate.of(2020, 1, 1)), eq(0), any(Admin.class)))
				.thenReturn(LocalDate.of(2020, 1, 1));
		when(mockAdminservice.calculateMaturityAmount(eq(0), any(Admin.class))).thenReturn(0);

		final Admin admin1 = new Admin();
		when(mockAdminservice.addPolicy(any(Admin.class))).thenReturn(admin1);

		final Admin result = adminControllerUnderTest.registerPolicy(admin);

	}
}
