
package com.policy.controller.test;

import com.policy.controller.UserController;
import com.policy.model.Admin;
import com.policy.model.User;
import com.policy.repo.UserRepo;
import com.policy.service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserControllerTest {

	@Mock
	private UserService mockUserservice;
	@Mock
	private UserRepo mockUserrepo;

	@InjectMocks
	private UserController userControllerTest;

	@Test
	public void testRegistration() {

		final User user = new User();

		when(mockUserservice.passwordGeneration()).thenReturn("result");
		when(mockUserservice.userType(eq(0), any(User.class))).thenReturn("result");
		//when(mockUserservice.findLast()).thenReturn("result");

		final User user1 = new User();
		when(mockUserservice.saveUser(any(User.class))).thenReturn(user1);

		final User result = userControllerTest.registration(user);

	}

	@Test
	public void testSearchPolicies() {

		final Admin admin = new Admin();
		final List<Admin> admins = List.of(admin);
		when(mockUserservice.getPolicies("policyType")).thenReturn(admins);
		final List<Admin> result = userControllerTest.searchPolicies("policyType");

	}

	@Test
	public void testSearchPolicies_UserServiceReturnsNoItems() {

		when(mockUserservice.getPolicies("policyType")).thenReturn(Collections.emptyList());

		final List<Admin> result = userControllerTest.searchPolicies("policyType");

		assertEquals(Collections.emptyList(), result);
	}

	@Test(expected = NoSuchElementException.class)
	public void testSearchPolicies_ThrowsNoSuchElementException() {

		final Admin admin = new Admin();
		final List<Admin> admins = List.of(admin);
		when(mockUserservice.getPolicies("policyType")).thenReturn(admins);

		// Run the test
		userControllerTest.searchPolicies("policyType");
	}
}
